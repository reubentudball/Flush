class Constants{
  static const List<String> listCleanliness = <String> ['Very Clean','Clean','Messy','Very Messy'];
  static const List<String> listTraffic = <String> ['High','Moderate','Low','None'];
  static const List<String> listSize = <String> ['Single-Use','2-4','5-7','More than 7'];
  static const List<String> listAccessibility = <String> ['Yes','No'];

}
