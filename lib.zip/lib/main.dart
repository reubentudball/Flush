import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'features/auth/presentation/LoginPage.dart';
import 'features/auth/presentation/SignUp.dart';
import 'features/auth/presentation/ForgotPassword.dart';
import 'features/bathroom/presentation/HomePage.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flush',
      initialRoute: '/login',
      getPages: [
        GetPage(name: '/login', page: () => LoginPage()),
        GetPage(name: '/sign-up', page: () => SignUpPage()),
        GetPage(name: '/forgot-password', page: () => ForgotPasswordPage()),
        GetPage(name: '/home', page: () => HomePage()),
      ],
    );
  }
}
